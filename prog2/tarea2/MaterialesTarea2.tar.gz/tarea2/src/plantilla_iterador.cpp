/* 1234567 */ // sustituiir con los 7 dígitos de la cédula

#include "../include/iterador.h"

struct _rep_iterador {};

TIterador crearIterador() {
  return NULL;
}

void liberarIterador(TIterador iter) {
}

bool estaDefinidaActual(TIterador iter) {
  return false;
}

void agregarAIterador(nat elem, TIterador const iter) {
}

void reiniciarIterador(TIterador const iter) {
}

void avanzarIterador(TIterador const iter) {
}

nat actualEnIterador(TIterador iter) {
  return 0;
}
